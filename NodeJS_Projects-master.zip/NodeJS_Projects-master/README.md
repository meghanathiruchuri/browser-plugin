
# Objective: 
The objective of this project is to find the source code from any web page and store it to database.
# Requirement:
Need to develop browser plugin which on-click should find the source code snippet from the active URL in the Web browser and store the code snippet to the database.
For more details, please refer the document located in the path - SourceCodeFind\docs\Source_Code_Find_Project_Instructions.docx 
